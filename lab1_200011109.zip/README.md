Course:
ECE 592 - Cryptograhpic Engineering and Hardware Security
NC State University
Dr.Aydin Aysu

Assignment 1: AES-128 Implementataion with a given fixed secret key and expanded keys.
